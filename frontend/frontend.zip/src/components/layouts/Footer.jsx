import styles from "../../styles/index.module.css";

function Footer() {
  return (
    <>
      <div></div>
    </>
  );
}

export default Footer;
